<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'readme' => 'Log404 Plugin for MODX Revolution
=======================================

**Author:** Manuel Barbiero - [Bizen Srl](https://www.bizen.it)

**Bugs and requests:** [Log404 Issues](https://github.com/bizen-srl/Log404/issues)

This plugin is for use with MODX Revolution. Log404 can be used to keep track of all urls with a 404 error with the ability to export records to a CSV file and clear the logs.

Installing Log404 for MODX Revolution
-----------------------------------------------

Go to System | Package Management on the main menu in the MODX Manager and click on the "Download Extras" button. That will take you to the Revolution Repository (AKA Web Transport Facility). Put Log404 in the search box and press Enter. Click on the "Download" button, and when it changes to "Downloaded," click on the "Finish" button. That should bring you back to your Package Management grid. Right click on Log404 and select "Install Package." The Log404 plugin should now be installed.

How to use it
-------------

Manage and review all urls with a 404 error through a visual interface that can be found under the "Components" menu.


LICENSE
=======

[MIT](https://opensource.org/licenses/MIT)

This package was built using Repoman (https://github.com/craftsmancoding/repoman/)',
    'changelog' => 'Changelog for Log404

Log404 1.0.0
---------------------------------
Initial Version

-- Custom CMP to review 404 urls
-- Download CSV file functionality
-- Clear Log functionality
-- EN and IT Lexicon',
    'license' => 'Copyright 2019 Bizen Srl

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '3d9e04f36f6f176b42ce628cbebf7ef1',
      'native_key' => 'log404',
      'filename' => 'modNamespace/8ee4b7f8ac16407faf5cfdab87cbc801.vehicle',
      'namespace' => 'log404',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '72cd805911612b629eb9c7892bfba8d1',
      'native_key' => NULL,
      'filename' => 'modCategory/dd65bea3466411b558c1ddc5daea5fc5.vehicle',
      'namespace' => 'log404',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOScriptVehicle',
      'class' => 'xPDOScriptVehicle',
      'guid' => 'cfea3ba8dbb791feb6f5f140c68ccd76',
      'native_key' => 'cfea3ba8dbb791feb6f5f140c68ccd76',
      'filename' => 'xPDOScriptVehicle/5c9daac4f31bba8a4e636ef508a50f25.vehicle',
      'namespace' => 'log404',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fead4cb097316d467b11dba27a7ce313',
      'native_key' => 'log404.version',
      'filename' => 'modSystemSetting/bc5c18c7b98e90cb6b1d6607c1b09ac1.vehicle',
      'namespace' => 'log404',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => '43c028e76f0a4a8b2f8ba87f63bfcb5b',
      'native_key' => NULL,
      'filename' => 'modAction/fc52ba654e7889d01ad0eb994e43580e.vehicle',
      'namespace' => 'log404',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'e4b25812091b67364c549a3b600ab3dc',
      'native_key' => 'log404.cmp.title',
      'filename' => 'modMenu/38ca83c15813f988cebc9a279af60f77.vehicle',
      'namespace' => 'log404',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9738e206f33151bec8794264fa06a39a',
      'native_key' => 'log404.log_path',
      'filename' => 'modSystemSetting/8eb949ced3fa0b21d2aa967791800353.vehicle',
      'namespace' => 'log404',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a958a9017752f891f88b8e5ab3f48dbf',
      'native_key' => 'log404.ignore_ips',
      'filename' => 'modSystemSetting/4dd026a8a68f1d66fc08a95b23569cb5.vehicle',
      'namespace' => 'log404',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e34ebb12f2c334d578b6d784d6f219c3',
      'native_key' => 'log404.log_max_lines',
      'filename' => 'modSystemSetting/fb1087e40e5b6be5aacb1b47d3ad0524.vehicle',
      'namespace' => 'log404',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4c235e0c0208352df0d0ed6ff96d6194',
      'native_key' => 'log404.header_cols',
      'filename' => 'modSystemSetting/dd458c6db449876bc6c29a3ac3890804.vehicle',
      'namespace' => 'log404',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '68ebe548bd7a15d22668c87d3dc7d999',
      'native_key' => 'log404.useragents',
      'filename' => 'modSystemSetting/44b2ac032b33fd5be475839e5d6c952b.vehicle',
      'namespace' => 'log404',
    ),
  ),
);