<?php
require_once (dirname(__DIR__) . '/log404items.class.php');
class Log404Items_mysql extends Log404Items {}