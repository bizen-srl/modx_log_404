<?php
class Log404Items extends xPDOSimpleObject {}