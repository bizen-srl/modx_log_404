<?php
return array (
    'namespace' => 'log404',
    'controller' => 'index',
    'haslayout' => 1,
    'lang_topics' => 'log404:default',
    'assets' => '',
    'help_url' =>  '',
);
