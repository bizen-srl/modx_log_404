<?php
return array(
    array(
        'text' => 'log404.cmp.title', // can be lexicon key
        'description' => 'log404.cmp.desc', // can be lexicon key
        'parent' => 'components',
        'action' => 'index',
        'icon' => '',
        'menuindex' => 0,
        'params' => '',
        'handler' => '',
        'permissions' => '',
        'namespace' => 'log404'
    ),
);